#!/usr/bin/env python3
"""
Comprehensive CLI Test Suite
Tests all 34 CLI commands across 9 command groups in real terminal execution.
Logs detailed results with proof and fixes issues automatically.
"""

import subprocess
import json
import sys
import os
import time
import traceback
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
import shutil

class CLITestRunner:
    """Test runner for CLI commands."""
    
    def __init__(self, test_results_dir: Optional[Path] = None):
        """Initialize test runner."""
        self.base_dir = Path(__file__).parent
        self.project_root = self.base_dir.parent.parent
        
        # Set up test results directory
        if test_results_dir:
            self.test_results_dir = Path(test_results_dir)
        else:
            timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            self.test_results_dir = self.base_dir / "test_results" / timestamp
        
        self.test_results_dir.mkdir(parents=True, exist_ok=True)
        (self.test_results_dir / "command_logs").mkdir(exist_ok=True)
        (self.test_results_dir / "artifacts").mkdir(exist_ok=True)
        
        # Test configuration
        self.test_config = {
            'username': os.getenv('4CULTURE_USERNAME', 'Keyisaccess'),
            'password': os.getenv('4CULTURE_PASSWORD', 'Outlaw22!!'),
            'openai_api_key': os.getenv('OPENAI_API_KEY'),
            'docs_folder': 'docs',
            'grant_name': 'Moving Stories: Short-Form Graphic Novels for King County Metro Transit RapidRide',
            'test_db_path': str(self.test_results_dir / "artifacts" / "test_grants.db"),
        }
        
        # Command results storage
        self.command_results: List[Dict[str, Any]] = []
        self.test_start_time = time.time()
        
        # Statistics
        self.stats = {
            'total': 0,
            'passed': 0,
            'failed': 0,
            'skipped': 0,
            'fixed': 0
        }
        
        print(f"Test results directory: {self.test_results_dir}")
        print(f"Test configuration loaded")
    
    def run_command(self, command_group: str, command: str, args: List[str] = None, 
                   timeout: int = 300, skip_if_no_tools: bool = False) -> Dict[str, Any]:
        """
        Execute a CLI command and capture results.
        
        Args:
            command_group: Command group (e.g., 'auth', 'data')
            command: Command name (e.g., 'login', 'extract')
            args: Additional arguments
            timeout: Command timeout in seconds
            skip_if_no_tools: Skip if MCP tools not available
            
        Returns:
            Dictionary with test results
        """
        self.stats['total'] += 1
        
        if args is None:
            args = []
        
        # Build command
        cmd = [
            sys.executable, '-m', 'agents.grant_scraper.sdk_cli',
            command_group, command
        ] + args
        
        full_command = ' '.join(cmd)
        
        result = {
            'timestamp': datetime.now().isoformat(),
            'command_group': command_group,
            'command': command,
            'full_command': full_command,
            'args': args,
            'exit_code': None,
            'success': False,
            'stdout': '',
            'stderr': '',
            'duration_ms': 0,
            'output_files': [],
            'errors': [],
            'warnings': [],
            'skipped': False,
            'skip_reason': None,
            'fixed': False,
            'fix_attempts': []
        }
        
        start_time = time.time()
        
        try:
            # Check if we should skip
            if skip_if_no_tools and command_group in ['auth', 'browser', 'form']:
                try:
                    from .mcp_server_config import MCPServerConfig
                    config = MCPServerConfig()
                    tools = config.connect_to_server('playwright')
                    if not tools:
                        result['skipped'] = True
                        result['skip_reason'] = 'MCP tools not available'
                        result['success'] = False
                        self.stats['skipped'] += 1
                        return result
                except Exception as e:
                    result['skipped'] = True
                    result['skip_reason'] = f'MCP tools check failed: {str(e)}'
                    result['success'] = False
                    self.stats['skipped'] += 1
                    return result
            
            # Execute command
            print(f"\n{'='*60}")
            print(f"Testing: {command_group} {command}")
            print(f"Command: {full_command}")
            print(f"{'='*60}")
            
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                cwd=str(self.project_root),
                env=os.environ.copy()
            )
            
            try:
                stdout, stderr = process.communicate(timeout=timeout)
                exit_code = process.returncode
            except subprocess.TimeoutExpired:
                process.kill()
                stdout, stderr = process.communicate()
                exit_code = -1
                result['errors'].append(f"Command timed out after {timeout} seconds")
            
            duration_ms = int((time.time() - start_time) * 1000)
            
            result['exit_code'] = exit_code
            result['stdout'] = stdout
            result['stderr'] = stderr
            result['duration_ms'] = duration_ms
            
            # Determine success
            # Exit code 2 for data validate is expected when validation fails (it's working correctly)
            if exit_code == 0 or (exit_code == 2 and command_group == 'data' and command == 'validate'):
                result['success'] = True
                self.stats['passed'] += 1
                if exit_code == 2:
                    print(f"✅ PASSED (exit code 2 = validation found issues, {duration_ms}ms)")
                else:
                    print(f"✅ PASSED ({duration_ms}ms)")
            else:
                result['success'] = False
                self.stats['failed'] += 1
                print(f"❌ FAILED (exit code: {exit_code}, {duration_ms}ms)")
                
                # Parse errors
                if stderr:
                    result['errors'].append(stderr)
                if stdout and 'error' in stdout.lower():
                    result['errors'].append(stdout)
            
            # Check for output files
            self._check_output_files(result, command_group, command)
            
            # Save individual command log
            log_file = self.test_results_dir / "command_logs" / f"{command_group}_{command}.json"
            with open(log_file, 'w') as f:
                json.dump(result, f, indent=2)
            
        except Exception as e:
            result['success'] = False
            result['errors'].append(f"Exception during execution: {str(e)}")
            result['errors'].append(traceback.format_exc())
            self.stats['failed'] += 1
            print(f"❌ EXCEPTION: {e}")
        
        self.command_results.append(result)
        return result
    
    def _check_output_files(self, result: Dict[str, Any], command_group: str, command: str):
        """Check for expected output files and copy to artifacts."""
        artifacts_dir = self.test_results_dir / "artifacts"
        
        # Check for common output patterns
        if command_group == 'data' and command == 'extract':
            # Look for JSON output files
            for file in self.project_root.glob("*.json"):
                if 'extract' in file.name.lower() or 'data' in file.name.lower():
                    dest = artifacts_dir / file.name
                    shutil.copy2(file, dest)
                    result['output_files'].append(str(dest))
        
        elif command_group == 'report' and command == 'dashboard':
            # Look for HTML dashboard
            dashboard_file = self.base_dir / "grant_dashboard.html"
            if dashboard_file.exists():
                dest = artifacts_dir / "grant_dashboard.html"
                shutil.copy2(dashboard_file, dest)
                result['output_files'].append(str(dest))
        
        elif command_group == 'browser' and command == 'screenshot':
            # Look for screenshots
            screenshots_dir = self.base_dir / "screenshots"
            if screenshots_dir.exists():
                for screenshot in screenshots_dir.glob("*.png"):
                    dest = artifacts_dir / screenshot.name
                    shutil.copy2(screenshot, dest)
                    result['output_files'].append(str(dest))
    
    def detect_issues(self, result: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Detect issues from command result."""
        issues = []
        
        if not result['success']:
            # Parse error patterns
            error_text = (result.get('stderr', '') + ' ' + result.get('stdout', '')).lower()
            
            if 'module not found' in error_text or 'no module named' in error_text:
                issues.append({
                    'type': 'missing_dependency',
                    'severity': 'high',
                    'message': 'Missing Python package',
                    'package': self._extract_package_name(error_text)
                })
            
            elif 'file not found' in error_text or 'no such file' in error_text:
                issues.append({
                    'type': 'missing_file',
                    'severity': 'medium',
                    'message': 'Missing file or directory',
                    'path': self._extract_path(error_text)
                })
            
            elif 'database' in error_text and ('locked' in error_text or 'cannot' in error_text):
                issues.append({
                    'type': 'database_error',
                    'severity': 'high',
                    'message': 'Database access error'
                })
            
            elif 'mcp' in error_text and 'not available' in error_text:
                issues.append({
                    'type': 'mcp_tools_unavailable',
                    'severity': 'medium',
                    'message': 'MCP browser tools not available'
                })
            
            elif 'api key' in error_text or 'authentication' in error_text:
                issues.append({
                    'type': 'auth_error',
                    'severity': 'high',
                    'message': 'Authentication or API key error'
                })
        
        return issues
    
    def _extract_package_name(self, text: str) -> Optional[str]:
        """Extract package name from error text."""
        import re
        match = re.search(r"no module named ['\"]([^'\"]+)['\"]", text)
        return match.group(1) if match else None
    
    def _extract_path(self, text: str) -> Optional[str]:
        """Extract file path from error text."""
        import re
        match = re.search(r"['\"]([^'\"]+\.(?:py|json|yaml|db|md))['\"]", text)
        return match.group(1) if match else None
    
    def attempt_fix(self, result: Dict[str, Any], issues: List[Dict[str, Any]]) -> bool:
        """Attempt to automatically fix detected issues."""
        fixed = False
        
        for issue in issues:
            fix_attempt = {
                'issue_type': issue['type'],
                'fix_attempted': False,
                'fix_success': False,
                'fix_message': ''
            }
            
            try:
                if issue['type'] == 'missing_dependency':
                    package = issue.get('package')
                    if package:
                        print(f"  Attempting to install missing package: {package}")
                        subprocess.run([sys.executable, '-m', 'pip', 'install', package], 
                                     capture_output=True, timeout=60)
                        fix_attempt['fix_attempted'] = True
                        fix_attempt['fix_success'] = True
                        fix_attempt['fix_message'] = f"Installed {package}"
                        fixed = True
                
                elif issue['type'] == 'missing_file':
                    path = issue.get('path')
                    if path:
                        file_path = Path(path)
                        if not file_path.exists():
                            # Try to create directory
                            if file_path.suffix:  # It's a file
                                file_path.parent.mkdir(parents=True, exist_ok=True)
                                file_path.touch()
                            else:  # It's a directory
                                file_path.mkdir(parents=True, exist_ok=True)
                            fix_attempt['fix_attempted'] = True
                            fix_attempt['fix_success'] = True
                            fix_attempt['fix_message'] = f"Created {path}"
                            fixed = True
                
                elif issue['type'] == 'database_error':
                    # Try to initialize database
                    from .grant_database import GrantDatabase
                    db_path = self.test_config.get('test_db_path', 'agents/grant_scraper/grants.db')
                    db = GrantDatabase(db_path)
                    db.close()
                    fix_attempt['fix_attempted'] = True
                    fix_attempt['fix_success'] = True
                    fix_attempt['fix_message'] = "Initialized database"
                    fixed = True
                
            except Exception as e:
                fix_attempt['fix_message'] = f"Fix failed: {str(e)}"
            
            result['fix_attempts'].append(fix_attempt)
        
        if fixed:
            result['fixed'] = True
            self.stats['fixed'] += 1
        
        return fixed
    
    def generate_report(self):
        """Generate HTML and JSON test reports."""
        # JSON Report
        json_report = {
            'test_run_id': self.test_results_dir.name,
            'timestamp': datetime.now().isoformat(),
            'duration_seconds': int(time.time() - self.test_start_time),
            'statistics': self.stats,
            'test_config': {k: v for k, v in self.test_config.items() if k != 'password'},
            'results': self.command_results
        }
        
        json_file = self.test_results_dir / "test_report.json"
        with open(json_file, 'w') as f:
            json.dump(json_report, f, indent=2)
        
        # HTML Report
        html_file = self.test_results_dir / "test_report.html"
        self._generate_html_report(html_file, json_report)
        
        print(f"\n{'='*60}")
        print("TEST SUITE COMPLETE")
        print(f"{'='*60}")
        print(f"Total: {self.stats['total']}")
        print(f"Passed: {self.stats['passed']} ✅")
        print(f"Failed: {self.stats['failed']} ❌")
        print(f"Skipped: {self.stats['skipped']} ⏭️")
        print(f"Fixed: {self.stats['fixed']} 🔧")
        print(f"\nReports:")
        print(f"  JSON: {json_file}")
        print(f"  HTML: {html_file}")
    
    def _generate_html_report(self, html_file: Path, json_report: Dict[str, Any]):
        """Generate HTML test report."""
        html = f"""<!DOCTYPE html>
<html>
<head>
    <title>CLI Test Report - {json_report['test_run_id']}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }}
        .header {{ background: #2c3e50; color: white; padding: 20px; border-radius: 5px; }}
        .stats {{ display: flex; gap: 20px; margin: 20px 0; }}
        .stat-box {{ background: white; padding: 15px; border-radius: 5px; flex: 1; text-align: center; }}
        .stat-box.passed {{ border-left: 5px solid #27ae60; }}
        .stat-box.failed {{ border-left: 5px solid #e74c3c; }}
        .stat-box.skipped {{ border-left: 5px solid #f39c12; }}
        .command-result {{ background: white; margin: 10px 0; padding: 15px; border-radius: 5px; }}
        .command-result.passed {{ border-left: 5px solid #27ae60; }}
        .command-result.failed {{ border-left: 5px solid #e74c3c; }}
        .command-result.skipped {{ border-left: 5px solid #f39c12; }}
        .command-header {{ font-weight: bold; font-size: 1.1em; margin-bottom: 10px; }}
        .details {{ margin-top: 10px; }}
        .details pre {{ background: #f8f9fa; padding: 10px; border-radius: 3px; overflow-x: auto; }}
        .error {{ color: #e74c3c; }}
        .success {{ color: #27ae60; }}
        .warning {{ color: #f39c12; }}
        .expandable {{ cursor: pointer; }}
        .hidden {{ display: none; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>CLI Test Report</h1>
        <p>Test Run ID: {json_report['test_run_id']}</p>
        <p>Timestamp: {json_report['timestamp']}</p>
        <p>Duration: {json_report['duration_seconds']} seconds</p>
    </div>
    
    <div class="stats">
        <div class="stat-box">
            <div style="font-size: 2em; font-weight: bold;">{self.stats['total']}</div>
            <div>Total Tests</div>
        </div>
        <div class="stat-box passed">
            <div style="font-size: 2em; font-weight: bold;">{self.stats['passed']}</div>
            <div>Passed</div>
        </div>
        <div class="stat-box failed">
            <div style="font-size: 2em; font-weight: bold;">{self.stats['failed']}</div>
            <div>Failed</div>
        </div>
        <div class="stat-box skipped">
            <div style="font-size: 2em; font-weight: bold;">{self.stats['skipped']}</div>
            <div>Skipped</div>
        </div>
    </div>
    
    <h2>Test Results</h2>
"""
        
        for result in self.command_results:
            # Handle skipped results that don't have success key
            if result.get('skipped'):
                status_class = 'skipped'
                status_icon = '⏭️'
            elif result.get('success', False):
                status_class = 'passed'
                status_icon = '✅'
            else:
                status_class = 'failed'
                status_icon = '❌'
            
            html += f"""
    <div class="command-result {status_class}">
        <div class="command-header">
            {status_icon} {result['command_group']} {result['command']}
            <span style="float: right; font-size: 0.9em; color: #7f8c8d;">
                {result['duration_ms']}ms
            </span>
        </div>
        <div>
            <strong>Command:</strong> <code>{result['full_command']}</code><br>
            <strong>Exit Code:</strong> {result.get('exit_code', 'N/A')}<br>
"""
            
            if result.get('skipped'):
                html += f"<span class='warning'><strong>Skipped:</strong> {result.get('skip_reason')}</span><br>"
            
            if result.get('output_files'):
                html += f"<strong>Output Files:</strong> {len(result['output_files'])} file(s)<br>"
            
            if result.get('errors'):
                html += f"<div class='error'><strong>Errors ({len(result['errors'])}):</strong><br>"
                for error in result['errors'][:3]:  # Show first 3 errors
                    html += f"<pre>{error[:500]}</pre>"
                html += "</div>"
            
            if result.get('fix_attempts'):
                html += f"<div><strong>Fix Attempts:</strong> {len(result['fix_attempts'])}</div>"
            
            html += """
        </div>
    </div>
"""
        
        html += """
</body>
</html>
"""
        
        with open(html_file, 'w') as f:
            f.write(html)


def main():
    """Main test execution."""
    runner = CLITestRunner()
    
    print("="*60)
    print("COMPREHENSIVE CLI TEST SUITE")
    print("="*60)
    print(f"Testing all 34 commands across 9 command groups")
    print(f"Results will be saved to: {runner.test_results_dir}")
    
    # Phase 1: Non-browser commands
    print("\n" + "="*60)
    print("PHASE 1: Non-Browser Commands")
    print("="*60)
    
    # Data commands
    print("\n--- Testing Data Commands ---")
    runner.run_command('data', 'extract', [
        '--grant-name', runner.test_config['grant_name'],
        '--docs-folder', runner.test_config['docs_folder'],
        '--output', str(runner.test_results_dir / 'artifacts' / 'extracted_data.json')
    ])
    
    runner.run_command('data', 'validate', [
        '--grant-name', runner.test_config['grant_name'],
        '--docs-folder', runner.test_config['docs_folder']
    ])
    
    runner.run_command('data', 'standardize', [
        '--grant-name', runner.test_config['grant_name'],
        '--docs-folder', runner.test_config['docs_folder'],
        '--output', str(runner.test_results_dir / 'artifacts' / 'standardized_data.json')
    ])
    
    runner.run_command('data', 'identify-docs', [
        '--grant-name', runner.test_config['grant_name'],
        '--docs-folder', runner.test_config['docs_folder']
    ])
    
    # Database commands
    print("\n--- Testing Database Commands ---")
    runner.run_command('database', 'add', [
        '--name', 'Test Grant',
        '--deadline', '2026-01-13',
        '--status', 'planned',
        '--priority', '5',
        '--db-path', runner.test_config['test_db_path']
    ])
    
    runner.run_command('database', 'list', [
        '--db-path', runner.test_config['test_db_path']
    ])
    
    # Get the grant ID from the list result
    grant_id = 1  # Default, will be updated if list works
    
    runner.run_command('database', 'get', [
        '--grant-id', str(grant_id),
        '--db-path', runner.test_config['test_db_path']
    ])
    
    runner.run_command('database', 'update', [
        '--grant-id', str(grant_id),
        '--status', 'in_progress',
        '--progress', '50',
        '--db-path', runner.test_config['test_db_path']
    ])
    
    runner.run_command('database', 'timeline', [
        '--db-path', runner.test_config['test_db_path']
    ])
    
    # Report commands
    print("\n--- Testing Report Commands ---")
    runner.run_command('report', 'dashboard')
    
    # Test report generate if we have workflow result
    # Note: report generate requires a result file from workflow execution
    # We'll skip it for now as it requires a full workflow run
    
    # Phase 2: Mapping commands (depends on data)
    print("\n" + "="*60)
    print("PHASE 2: Mapping Commands")
    print("="*60)
    
    # Check if we have extracted data
    extracted_file = runner.test_results_dir / 'artifacts' / 'extracted_data.json'
    if extracted_file.exists():
        runner.run_command('mapping', 'map', [
            '--grant-name', runner.test_config['grant_name'],
            '--data-file', str(extracted_file),
            '--output', str(runner.test_results_dir / 'artifacts' / 'mapped_fields.json')
        ])
        
        mapped_file = runner.test_results_dir / 'artifacts' / 'mapped_fields.json'
        if mapped_file.exists():
            runner.run_command('mapping', 'validate-map', [
                '--mapped-file', str(mapped_file)
            ])
            
            runner.run_command('mapping', 'create-instructions', [
                '--mapped-file', str(mapped_file),
                '--output', str(runner.test_results_dir / 'artifacts' / 'instructions.json')
            ])
    
    # Phase 3: Browser commands
    print("\n" + "="*60)
    print("PHASE 3: Browser Commands")
    print("="*60)
    
    # Test browser commands only if MCP tools are available
    try:
        import sys
        sys.path.insert(0, str(runner.project_root))
        from agents.grant_scraper.mcp_server_config import MCPServerConfig
        config = MCPServerConfig()
        tools = config.connect_to_server('playwright')
        if tools:
            runner.run_command('browser', 'navigate', [
                '--url', 'https://apply.4culture.org/login'
            ], skip_if_no_tools=False)
            
            runner.run_command('browser', 'wait', [
                '--time', '2'
            ], skip_if_no_tools=False)
            
            runner.run_command('browser', 'snapshot', [
                '--output', str(runner.test_results_dir / 'artifacts' / 'snapshot.json')
            ], skip_if_no_tools=False)
            
            runner.run_command('browser', 'screenshot', [
                '--name', 'test_screenshot'
            ], skip_if_no_tools=False)
            
            runner.run_command('browser', 'find', [
                '--description', 'username input field or text input'
            ], skip_if_no_tools=False)
            
            # Note: get-url command doesn't exist in CLI, skipping
        else:
            print("⏭️  Skipping browser commands (MCP tools not available)")
            for cmd in ['navigate', 'wait', 'snapshot', 'screenshot', 'find', 'get-url']:
                result = {
                    'timestamp': datetime.now().isoformat(),
                    'command_group': 'browser',
                    'command': cmd,
                    'full_command': f'python3 -m agents.grant_scraper.sdk_cli browser {cmd} (skipped)',
                    'args': [],
                    'exit_code': None,
                    'success': False,
                    'stdout': '',
                    'stderr': '',
                    'duration_ms': 0,
                    'output_files': [],
                    'errors': [],
                    'warnings': [],
                    'skipped': True,
                    'skip_reason': 'MCP tools not available',
                    'fixed': False,
                    'fix_attempts': []
                }
                runner.command_results.append(result)
                runner.stats['skipped'] += 1
    except Exception as e:
        print(f"⏭️  Skipping browser commands (MCP tools check failed: {e})")
        for cmd in ['navigate', 'wait', 'snapshot', 'screenshot', 'find', 'get-url']:
            result = {
                'timestamp': datetime.now().isoformat(),
                'command_group': 'browser',
                'command': cmd,
                'full_command': f'python3 -m agents.grant_scraper.sdk_cli browser {cmd} (skipped)',
                'args': [],
                'exit_code': None,
                'success': False,
                'stdout': '',
                'stderr': '',
                'duration_ms': 0,
                'output_files': [],
                'errors': [],
                'warnings': [],
                'skipped': True,
                'skip_reason': f'MCP tools check failed: {str(e)}',
                'fixed': False,
                'fix_attempts': []
            }
            runner.command_results.append(result)
            runner.stats['skipped'] += 1
    
    # Phase 4: Auth commands
    print("\n" + "="*60)
    print("PHASE 4: Auth Commands")
    print("="*60)
    
    # Test auth commands only if MCP tools are available
    try:
        import sys
        sys.path.insert(0, str(runner.project_root))
        from agents.grant_scraper.mcp_server_config import MCPServerConfig
        config = MCPServerConfig()
        tools = config.connect_to_server('playwright')
        if tools:
            runner.run_command('auth', 'login', [
                '--username', runner.test_config['username'],
                '--password', runner.test_config['password'],
                '--non-interactive',
                '--skip-mcp-setup'
            ], timeout=120, skip_if_no_tools=False)
            
            runner.run_command('auth', 'logout', [], skip_if_no_tools=False)
        else:
            print("⏭️  Skipping auth commands (MCP tools not available)")
            for cmd in ['login', 'logout']:
                result = {
                    'timestamp': datetime.now().isoformat(),
                    'command_group': 'auth',
                    'command': cmd,
                    'full_command': f'python3 -m agents.grant_scraper.sdk_cli auth {cmd} (skipped)',
                    'args': [],
                    'exit_code': None,
                    'success': False,
                    'stdout': '',
                    'stderr': '',
                    'duration_ms': 0,
                    'output_files': [],
                    'errors': [],
                    'warnings': [],
                    'skipped': True,
                    'skip_reason': 'MCP tools not available',
                    'fixed': False,
                    'fix_attempts': []
                }
                runner.command_results.append(result)
                runner.stats['skipped'] += 1
    except Exception as e:
        print(f"⏭️  Skipping auth commands (MCP tools check failed: {e})")
        for cmd in ['login', 'logout']:
            result = {
                'timestamp': datetime.now().isoformat(),
                'command_group': 'auth',
                'command': cmd,
                'full_command': f'python3 -m agents.grant_scraper.sdk_cli auth {cmd} (skipped)',
                'args': [],
                'exit_code': None,
                'success': False,
                'stdout': '',
                'stderr': '',
                'duration_ms': 0,
                'output_files': [],
                'errors': [],
                'warnings': [],
                'skipped': True,
                'skip_reason': f'MCP tools check failed: {str(e)}',
                'fixed': False,
                'fix_attempts': []
            }
            runner.command_results.append(result)
            runner.stats['skipped'] += 1
    
    # Phase 5: Narrative commands (optional)
    print("\n" + "="*60)
    print("PHASE 5: Narrative Commands (Optional)")
    print("="*60)
    
    if runner.test_config.get('openai_api_key'):
        runner.run_command('narrative', 'generate', [
            '--grant-name', runner.test_config['grant_name'],
            '--narrative-type', 'project_description',
            '--openai-api-key', runner.test_config['openai_api_key'],
            '--output', str(runner.test_results_dir / 'artifacts' / 'narrative.txt')
        ])
    else:
        result = {
            'timestamp': datetime.now().isoformat(),
            'command_group': 'narrative',
            'command': 'generate',
            'full_command': 'python3 -m agents.grant_scraper.sdk_cli narrative generate (skipped)',
            'args': [],
            'exit_code': None,
            'success': False,
            'stdout': '',
            'stderr': '',
            'duration_ms': 0,
            'output_files': [],
            'errors': [],
            'warnings': [],
            'skipped': True,
            'skip_reason': 'OpenAI API key not available',
            'fixed': False,
            'fix_attempts': []
        }
        runner.command_results.append(result)
        runner.stats['skipped'] += 1
        print("⏭️  Skipping narrative tests (OpenAI API key not available)")
    
    # Phase 6: Form commands (if auth worked)
    print("\n" + "="*60)
    print("PHASE 6: Form Commands")
    print("="*60)
    
    # Check if we have a logged-in session
    auth_success = any(r.get('command_group') == 'auth' and r.get('command') == 'login' and r.get('success') 
                      for r in runner.command_results)
    
    if auth_success:
        runner.run_command('form', 'extract-structure', [
            '--grant-name', runner.test_config['grant_name']
        ], skip_if_no_tools=False)
        
        # Other form commands would require actual form data
        for cmd in ['start', 'fill', 'fill-all', 'validate', 'save']:
            result = {
                'timestamp': datetime.now().isoformat(),
                'command_group': 'form',
                'command': cmd,
                'full_command': f'python3 -m agents.grant_scraper.sdk_cli form {cmd} (skipped)',
                'args': [],
                'exit_code': None,
                'success': False,
                'stdout': '',
                'stderr': '',
                'duration_ms': 0,
                'output_files': [],
                'errors': [],
                'warnings': [],
                'skipped': True,
                'skip_reason': 'Requires active grant application form',
                'fixed': False,
                'fix_attempts': []
            }
            runner.command_results.append(result)
            runner.stats['skipped'] += 1
    else:
        print("⏭️  Skipping form commands (auth required)")
        for cmd in ['start', 'extract-structure', 'fill', 'fill-all', 'validate', 'save']:
            result = {
                'timestamp': datetime.now().isoformat(),
                'command_group': 'form',
                'command': cmd,
                'full_command': f'python3 -m agents.grant_scraper.sdk_cli form {cmd} (skipped)',
                'args': [],
                'exit_code': None,
                'success': False,
                'stdout': '',
                'stderr': '',
                'duration_ms': 0,
                'output_files': [],
                'errors': [],
                'warnings': [],
                'skipped': True,
                'skip_reason': 'Auth required',
                'fixed': False,
                'fix_attempts': []
            }
            runner.command_results.append(result)
            runner.stats['skipped'] += 1
    
    # Phase 7: Workflow commands
    print("\n" + "="*60)
    print("PHASE 7: Workflow Commands")
    print("="*60)
    
    runner.run_command('workflow', 'custom', [
        '--grant-name', runner.test_config['grant_name'],
        '--steps', 'extract,standardize,map'
    ])
    
    # Test full workflow in dry-run mode if possible
    runner.run_command('workflow', 'full', [
        '--grant-name', runner.test_config['grant_name'],
        '--dry-run'
    ])
    
    # Analyze results and attempt fixes
    print("\n" + "="*60)
    print("ANALYZING RESULTS AND ATTEMPTING FIXES")
    print("="*60)
    
    for result in runner.command_results:
        if not result.get('success') and not result.get('skipped'):
            issues = runner.detect_issues(result)
            if issues:
                print(f"\nIssues detected for {result['command_group']} {result['command']}:")
                for issue in issues:
                    print(f"  - {issue['type']}: {issue['message']}")
                
                fixed = runner.attempt_fix(result, issues)
                if fixed:
                    print(f"  🔧 Attempted fixes, re-running command...")
                    # Re-run the command
                    new_result = runner.run_command(
                        result['command_group'],
                        result['command'],
                        result.get('args', []),
                        skip_if_no_tools=result.get('skip_if_no_tools', False)
                    )
                    if new_result['success']:
                        print(f"  ✅ Command passed after fix!")
    
    # Generate reports
    print("\n" + "="*60)
    print("GENERATING REPORTS")
    print("="*60)
    
    runner.generate_report()
    
    # Return exit code based on results
    if runner.stats['failed'] > 0:
        sys.exit(1)
    else:
        sys.exit(0)


if __name__ == '__main__':
    main()

